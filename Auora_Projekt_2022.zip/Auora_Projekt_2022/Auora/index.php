<?php 
include('connect.php');
include('validator.php');
include('command.php');







if(isset($_POST['press'])){
    $sql1 = "DELETE FROM `arts` WHERE id=".$_POST['sel'];
    command($sql1,$pol);
}

if(isset($_POST['add_art'])){


    echo "well done";
    $validation = new formValidator($_POST);
    $errors = $validation->validateForm();




    
    $title = $_POST['tytul'];
    $description = $_POST['opis'];
    $status = $_POST['status'];
    $category = $_POST['category'];
    $sql2 = "INSERT INTO arts (`title`,`description`,`status`,`cat_id`)
        VALUES ('$title','$description',$status,$category)";
    command($sql2,$pol);


}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">


    <title>Document</title>
</head>
<body>
    <div class="containter">
        <div class="row home align-items-center">
            <div class="row align-items-center">
            
                <div class="col">
                <button class="nav_button"  id="back"><span>change</span></button>
                </div> 

                <div class="col">
                <h1 class="links">welcome</h1>
              
                </div> 
                <div class="col">
                <button class="nav_button"  id="forward"><span>change</span></button>
                </div> 
                
            </div>
            
        </div>


        <div class="row main align-items-center">

            <div class="row align-items-center">

                <div class="col formbase">

                    <div id="content">
                    

                    </div>
                 

               </div> 
            
            </div>
        </div>



    </div>
    
   
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
	<script src="switch.js"></script>
</body>
</html>

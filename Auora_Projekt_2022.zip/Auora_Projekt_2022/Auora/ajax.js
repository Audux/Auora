// $('#bt').click(function () { 
 
// $.ajax({
//     url: "plik.txt",
//     success: function (response) {
//         // alert('Wszytko ok');
//         console.log(response);
//         $('#content').html(response);
      
//     },
//     error: function(){
//         alert('cos poszło nie tak');
//     },
//     complete: function(){
//         alert('KONIEC');
//     }
// });


// });


$('#bt').click(function () { 

    // $.get("sample_data.php", 
    //     function (data) {
    //         $('#content').html('');
    //     $('#content').append(data);
    //     });

    // $.get("sample_data.php",{dane: 'MOJE DANE ZE SKRYPTU'},
    //         function (data) {
    //             $('#content').html('');
    //             $('#content').append(data);
    //         },
            
    //     );

    // $.ajax({
    //     type: "GET",
    //     url: "sample_data.php",
    //     data: "dane=Moje dnae",
    //     success: function (response) {
    //         $('#content').html('');
    //         $('#content').append(response);  
    //     }
    // });
    // $.ajax({
    //     type: "POST",
    //     url: "sample_data.php",
    //     data: "dane_post=Moje dnae nie jawnie",
    //     success: function (response) {
    //         $('#content').html('');
    //         $('#content').append(response);  
    //     }
    // });

    // $.getJSON("data.json",
    //     function (data) {
    //     //   console.log(data) ;
    //         var prod=data.products;
    //         var ul=$("<ul>");
    //         var itms='';
    //         $.each(prod, function (i,v) { 
    //              itms+='<li>'+v.name+'</li>';
    //              console.log(itms);
    //         });
    //         ul.html(itms);
    //         console.log(ul);
    //         $('#content').html('');
    //         $('#content').append(ul);


    //     }
    // );

    $.ajax({
       
        url: 'https://jsonplaceholder.typicode.com/users',
        statusCode: {
            404: function() {
              alert( "page not found" );
            },
            200: function() {
                console.log("Wszytko ok");
              }
          }
       
    }).done(data=>{
        console.log(data);
        $.each(data, function (v) { 
            let obj=data[v];
            let ul=$("<ul>");
            let itms='';
                for( let key in obj){
                    itms+='<li>'+obj[key]+'</li>';

                }      

            ul.html(itms);
            
           
            $('#content').append(ul);

        });


    });

});
// $(document).ready(function(){

// $('div').css('color','blue');
// $('div>i').css('color','blue');
// $('div.moja').css('color','blue');
// $('div#dane').css('color','red');
// $('.moja').css('color','green');
// $('#dane').css('color','red');

// $('div:first').css('color','blue');
// $('div:last').css('color','blue');

// $('div:even').css('color','blue');
// $('div:odd').css('color','red');

// $('div:gt(2)').css('color','blue');
// $('div:lt(2)').css('color','blue');
// $('div:eq(2)').css('color','blue');
// $('div:not(div:eq(2))').css('color','blue');

// $('div:gt(2)').css({
//     'color':'red',
//     'font-size':'23px',
//     'background-color':'green'
// });

// dane={
//     'color':'red',
//     'cos':12,
//     'metoda':()=>{
//         console.log(this);
//     }


// $('*').css({
//     'color':'red',
//     'font-size':'23px',
//     'background-color':'green'
// });

// $('img[alt="opis"]').css({
//         'border':'2px solid red',
//         'background-color':'green'
//     });

// $('img[alt*="op"]').css({
//         'border':'2px solid red',
//         'background-color':'green'
//     });

// $('img[src$=".jpg"]').css({
//     'border':'2px solid red',
//     'background-color':'green'
// });

// $('img[src^="dan"]').css({
//     'border':'2px solid red',
//     'background-color':'green'
// });



// let x=$('div.cos').html();
// $('div.cos').html(x+' dodane <i>CDOOSHK</i>');
// $('div.cos').text(x+' dodane <i>CDOOSHK</i>');

// $('div').addClass("cl_dane");
// $('div').removeClass("cl_dane");
// let x=$('div').hasClass("moja");

// $('div').click(function(){

//     $(this).html('Npias');


// });
// $('div').mouseover(function(){

//     $(this).css({
//             'color':'red',
//             'font-size':'23px',
//             'background-color':'green'
//         });


// });

// $('div').mouseout(function(){

//     $(this).addClass("cl_dane");


// });


// $('div').hover(function(){
//     $(this).addClass("cl_dane");
// });


// $('div').mouseout(function(){

//     $('div.moja').hide();


// });
// $('div.moja').hide();

// $('div').mouseout(function(){

//     $('div.moja').show();


// });


// $('div.moja').hide();




// })
<?php 

include('connect.php');


$sql="SELECT arts.title, category.title as cat_tl, arts.`description`, arts.`status`  FROM `arts`
INNER JOIN category ON arts.cat_id=category.id ORDER BY arts.id DESC";
$res=$pol->query($sql,PDO::FETCH_ASSOC);

?>

<style> 
body{

    background-color: black;
}

</style>

<div id="menu">
<table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Decription</th>
            <th scope="col">Category</th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>



<?php 
        
          
    
        
         
       $i = 0;
        foreach ($res as $value){
            $i++;
          $title = $value['title'];
          $description = $value['description'];
          $status = $value['status'];
          $category = $value['cat_tl'];
          if($status == 0){
              $status = "in progress";
          } elseif($status == 1){
              $status = "completed";
          } elseif($status ==2){
              $status = "cancelled";
          }

          echo "<tr>
              <th scope='row'>$i</th>
              <td>$title</td>
              <td>$description</td>
              <td>$category</td>
              <td>$status</td>
            </tr>";
          


        }
        
        
        ?>

</tbody>
      </table>

</div>

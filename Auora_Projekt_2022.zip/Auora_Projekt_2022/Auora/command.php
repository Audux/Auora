<?php 

function command($sql,$pol) {
    $pol->exec($sql);
    
    header('Location:index.php');
    //$_POST['stan'] = "Finito";
    
}


?>
$(document).ready(function () {
    $("#content").css({opacity: '0.0'})
    let colors = ['#000000','rgb(236, 236, 40)','#FF004A','#008DB3']
    let site_forms = ['show.php','delete.php', 'add.php', 'edit.php'];

    $.ajax({
        type: "GET",
        url: site_forms[0],
       
    success: function (response) {
            $('#extrainfo').html("")
            $('#content').html(response);
            $(".formbase").css("background-color", colors[0]);
        }
    });
    $("#content").delay(300).animate({opacity: '1.0'});

    
    let i = 0;
    $("#forward").click( async() => {
        $("#content").css({ opacity: '0.0' });
        
        (i == site_forms.length-1) ? i = 0 : i++;
        
        $.ajax({
                type: "GET",
                url: site_forms[i],
               
            success: function (response) {
                    $('#extrainfo').html("")
                    $('#content').html(response);
                    $(".formbase").css("background-color", colors[i]);
                }
        });
        

        $("#content").animate({opacity: '1.0'});


    });


    $("#back").click( async() => {
        $("#content").css({ opacity: '0.0' });
        
        (i == 0) ? i = site_forms.length-1 : i--;
        
        $.ajax({
                type: "GET",
                url: site_forms[i],
               
            success: function (response) {
                    $('#extrainfo').html("")
                    $('#content').html(response);
                    $(".formbase").css("background-color", colors[i]);
                }
        });
        

        $("#content").animate({opacity: '1.0'});


    });


    $(".links").click( async() => {
      
        let i = 0;
        if (i == 0) {
            $(".links").animate({ letterSpacing: "10px" }, 2000);
            i++;
            console.log(i);
        }
        else {
        
            $(".links").animate({ letterSpacing: "-10px" }, 2000);
            i--;
        }
   

    });

    


})

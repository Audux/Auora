<?php 
include('connect.php');
include('validator.php');
include('command.php');
if(!isset($_POST['make_edit']) && !isset($_POST['edit_art'])){

    header('Location:index.php');



}
else{

$selected = $_POST['sel'];
$sql="SELECT * FROM `arts` WHERE id = $selected";
  $res_2 = $pol->query($sql,PDO::FETCH_ASSOC);

  foreach ($res_2 as $value){
          
    $id = $value['id'];
    $title = $value['title'];
    $description = $value['description'];
    $state = $value['status'];
    $cat_id = $value['cat_id'];
  }





$sql="SELECT * FROM `category`";
  $res=$pol->query($sql,PDO::FETCH_ASSOC);
  if(isset($_POST['edit_art'])){

  $validation = new formValidator($_POST);
  $errors = $validation->validateForm();

  $id = $_POST['id'];
  $title = $_POST['tytul'];
  $description = $_POST['opis'];
  $state = $_POST['status'];
  $cat_id = $_POST['category'];

  if (count($errors) == 0){
    $sql2 = "UPDATE arts
    SET `title` = '$title', `description` = '$description', `status` = $state, `cat_id` = $cat_id
    WHERE `id` = $id";
    command($sql2,$pol);


  }



  //echo "weeeelll done...";
  }


}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<style>
body{

background-color: #008DB3;

}
</style>    

    <title>Document</title>
</head>
<body>
    <br/><br/>
<div class="container">
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" >
<legend><h1 class="headers formtext">Edit article</h1></legend>
  <div class="mb-3">
  
    <input type="hidden" name = "id" value="<?php echo $id ?>">
    <input type="hidden" name = "sel" value="<?php echo $selected ?>">
    <label for="exampleInputEmail1" class="form-label">Title</label>
    <input type="text" value="<?php echo $title ?>" name="tytul" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div class="errors">
    <?php echo $errors['tytul'] ?? '' ?>
    </div>
  </div>
  
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Description</label>
    <input type="text" value="<?php echo $description ?>" name="opis" class="form-control" id="exampleInputPassword1">

    <div class="errors">
    <?php echo $errors['opis'] ?? '' ?>
    </div>

  </div>


  <div class="form-check">
      <input class="form-check-input" type="radio" name="status" value="0" id="flexRadioDefault1" <?php echo ($state == 0 ? "checked" : ''); ?>>
      <label class="form-check-label" for="flexRadioDefault1">
        In progress
      </label>
</div>
<div class="form-check">
      <input class="form-check-input" type="radio" name="status" id="flexRadioDefault2" value="1"  <?php echo ($state == 1 ? "checked" : ''); ?>>
      <label class="form-check-label" for="flexRadioDefault2">
        Completed
      </label>
</div>
<div class="form-check">
      <input class="form-check-input" type="radio" name="status" id="flexRadioDefault3" value="2" <?php echo ($state == 2 ? "checked" : ''); ?>>
      <label class="form-check-label" for="flexRadioDefault3">
        Cancelled
      </label>

    
</div>
<div class="mb-3">
      
      <select id="disabledSelect" name="category" class="form-select formtext" >
      <?php 
        
        foreach ($res as $value){
          $choice = ($cat_id == $value['id']) ? "selected='selected'" : ''; 
          echo "<option $choice  value='".$value['id']."'>".$value['title']."</option>";
          


        }
        
        
        ?>

      </select>
    </div>
  <button type="submit" name="edit_art" class="btn btn-success">Submit Edit</button>
</form>
</div>

</body>
</html>




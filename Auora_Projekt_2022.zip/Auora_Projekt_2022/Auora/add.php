<?php 
include('connect.php');
include('validator.php');
include('command.php');

  $sql="SELECT * FROM `category`";
  $res=$pol->query($sql,PDO::FETCH_ASSOC);


  if(isset($_POST['add_art'])){
    
    $validation = new formValidator($_POST);
    $errors = $validation->validateForm();

    if (count($errors) == 0){
      

      $title = $_POST['tytul'];
    $description = $_POST['opis'];
    $status = $_POST['status'];
    $category = $_POST['category'];
    $sql2 = "INSERT INTO arts (`title`,`description`,`status`,`cat_id`)
        VALUES ('$title','$description',$status,$category)";
    command($sql2,$pol);


    }

  }
  

?>

<link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<style>
body{

  background-color: #FF004A;
}

</style>    

<div class="container">
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" >
<legend><h1 class="headers formtext">Add an article</h1></legend>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Title</label>
    <input type="text" name="tytul" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div class="errors">
    <?php echo $errors['tytul'] ?? '' ?>
    </div>
  </div>
  
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Description</label>
    <input type="text" name="opis" class="form-control" id="exampleInputPassword1">

    <div class="errors">
    <?php echo $errors['opis'] ?? '' ?>
    </div>

  </div>


  <div class="form-check">
      <input class="form-check-input" type="radio" name="status" value="0" id="flexRadioDefault1" checked>
      <label class="form-check-label" for="flexRadioDefault1">
        In progress
      </label>
</div>
<div class="form-check">
      <input class="form-check-input" type="radio" name="status" id="flexRadioDefault2" value="1" >
      <label class="form-check-label" for="flexRadioDefault2">
        Completed
      </label>
</div>
<div class="form-check">
      <input class="form-check-input" type="radio" name="status" id="flexRadioDefault3" value="2" >
      <label class="form-check-label" for="flexRadioDefault3">
        Cancelled
      </label>

    
</div>
<div class="mb-3">
      
      <select id="disabledSelect" name="category" class="form-select formtext" >
      <?php 
        
        foreach ($res as $value){
          
          echo "<option value='".$value['id']."'>".$value['title']."</option>";
          


        }
        
        
        ?>

      </select>
    </div>
  <button type="submit" name="add_art" class="btn btn-primary">Submit Article</button>
</form>
</div>


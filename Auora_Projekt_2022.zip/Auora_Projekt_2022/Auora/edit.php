<?php 
include('connect.php');

  $sql="SELECT arts.id, arts.title, category.title as cat_tl  FROM `arts`
  INNER JOIN category ON arts.cat_id=category.id";
  $res=$pol->query($sql,PDO::FETCH_ASSOC);
  




?>
<style>
body{
  background-color: #008DB3;
}

</style>


<form method = "POST" action="confirm_edit.php">
  <fieldset>
    <legend><h1 class="headers formtext">Make an edit</h1></legend>
    
    <div class="mb-3">
      <label for="disabledSelect" class="form-label formtext">Select an article</label>
      <select id="disabledSelect" class="form-select formtext" name="sel">
        <?php 
        
        foreach ($res as $value){
          
          echo "<option value='".$value['id']."'>".$value['title']."(".$value['cat_tl'].")</option>";
          


        }
        
        
        ?>
      </select>
    </div>
    <div class="mb-3">
      <div class="form-check">
          
      </div>
    </div>
    <button name="make_edit" type="submit" class="btn btn-success formtext">Edit</button>
  </fieldset>
</form>
<?php 
include('connect.php');

  $sql="SELECT * FROM `arts`";
  $res=$pol->query($sql,PDO::FETCH_ASSOC);
  

  // if(isset($_POST['press'])){
  //     //echo $_POST['sel'];
  //     $sql="DELETE FROM `arts` WHERE id=".$_POST['sel'];
  //     $pol->exec($sql);
  //     header('Location:delete.php');
  // }




?>

<style>
body{
  background-color: rgb(236, 236, 40);
}

</style>


<form method = "POST" action="">
  <fieldset>
    <legend><h1 class="headers formtext">Remove an article</h1></legend>
    
    <div class="mb-3">
      <label for="disabledSelect" class="form-label formtext">Select an article</label>
      <select id="disabledSelect" class="form-select formtext" name="sel">
        <?php 
        
        foreach ($res as $value){
          
          echo "<option value='".$value['id']."'>".$value['title']."</option>";
          


        }
        
        
        ?>
      </select>
    </div>
    <div class="mb-3">
      <div class="form-check">
          
      </div>
    </div>
    <button name="press" type="submit" class="btn btn-danger formtext">Delete</button>
  </fieldset>
</form>


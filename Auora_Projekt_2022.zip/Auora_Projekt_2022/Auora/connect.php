<?php
$dbser='localhost';
$dbuser='root';
$dbpas='';
$dbbase='articles';

$pol = new PDO("mysql:host=$dbser;dbname=$dbbase",$dbuser,$dbpas);

?>
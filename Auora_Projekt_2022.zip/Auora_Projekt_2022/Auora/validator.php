<?php 


class formValidator {

    private $data;
    private $errors = [];
    private static $fields = ['tytul', 'opis'];

    public function __construct($post_data){
        $this->data = $post_data;
    }

    public function validateForm(){
        foreach(self::$fields as $field){
            if(!array_key_exists($field, $this->data)){
                trigger_error("$field is not present in data");
                return;

            }
        }
        $this->validateTitle();
        $this->validateDesc();

        return $this->errors;
    }

    private function validateTitle(){
        $val = trim($this->data['tytul']);


        if(empty($val)){
            $this->addError('tytul','title cannot be empty');
        } 



    }

    private function validateDesc(){

        $val = trim($this->data['opis']);

        if(empty($val)){
            $this->addError('opis','description cannot be empty');
        } 


    }


    private function addError($key, $val){
        $this->errors[$key] = $val;

    }

}





?>